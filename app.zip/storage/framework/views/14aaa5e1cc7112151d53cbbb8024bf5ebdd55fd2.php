<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mental Health - Profil</title>

    <link rel="stylesheet" href="/css/navbar/style.css">
    <link rel="stylesheet" href="/css/footer/style.css">
    <link rel="icon" href="/images/main/logo2.png" type="image/png">
    <link rel="stylesheet" href="/css/profileuser/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>

<body>

    
    <?php echo $__env->make('layout.navbarDefault', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <img class="bg-profile" src="<?php echo e(asset('images/profile/bg.png')); ?>" alt="">

    <div class="container-fluid mb-3 p-5" style="margin-top: -145px">
        <div class="row">
            <div class="col-lg-3 col-md-12 wrap-profile">
                <?php echo $__env->make('layout/profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-lg-8 col-md-12 animate__animated animate__slideInRight wrap-profile-2 description">
                <div class="container-fluid wrap-list" style="border-bottom: 3px solid #D9D9D9;">
                    <div class="list" style="display: flex; justify-content:space-between">
                        <?php if($profilUser == true): ?>
                        <h5><a href="/profile-aboutuser/<?php echo e(Auth::user()->id); ?>">Tentang</a></h5>
                        <h5><a style="color: #0a6ef6" href="/profile-articleuser/<?php echo e(Auth::user()->id); ?>">Artikel</a></h5>
                        <h5><a href="/profile-storyuser/<?php echo e(Auth::user()->id); ?>">Cerita</a></h5>

                        <?php else: ?>
                        <h5><a href="/profile-aboutuser/<?php echo e($profil->id); ?>">Tentang</a></h5>
                        <h5><a style="color: #0a6ef6" href="/profile-articleuser/<?php echo e($profil->id); ?>">Artikel</a></h5>
                        <h5><a href="/profile-storyuser/<?php echo e($profil->id); ?>">Cerita</a></h5>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="container list-article" style="padding-top: 25px">
                    <?php if($errors->any() || Session::get('success')): ?>
                                    <?php echo $__env->make('layout/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <div class="row mb-3">
                        <?php if($profilUser == true): ?>
                        <div class="upload-story mb-5" style="text-align: right;">
                            <a href="/upload-articleuser">Posting</a>
                        </div>
                        <?php endif; ?>

                        <?php if($listArticle->isEmpty() && $profilUser == true): ?>
                        <p>Posting Artikel Pertama Anda</p>
                        <?php endif; ?>
                        <?php if($listArticle->isEmpty() && $profilUser == false): ?>
                        <p>Pengguna ini belum memosting Artikel sama sekali</p>
                        <?php endif; ?>

                        <?php $__currentLoopData = $listArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 mb-3">
                                <div class="card-artikel">
                                    <div class="gambar-artikel"
                                        style="background-image: url('<?php echo e(asset($article->image)); ?>'); background-size: cover;background-position: center;background-repeat: no-repeat; width: 100%; height: auto;">

                                    </div>

                                    <div class="isi-artikel">
                                        <h4><?php echo e($article->title); ?></h4>
                                        <div class="penuli-tombol">
                                            <div class="nama-tombol">

                                                <p><?php echo e($article->users->name); ?></p>
                                                <a href="/article/<?php echo e($article->id); ?>">Lihat</a>
                                            </div>
                                            <?php if($profilUser == true): ?>
                                            <div class="hapus-edit mt-2">
                                                <div class="edit">

                                                    <a href="/edit-article/<?php echo e($article->id); ?>">Edit</a>
                                                </div>
                                                <div class="hapus mt-3">

                                                    <a href="/delete-article/<?php echo e($article->id); ?>">Hapus</a>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                        </div>
                                        <div class="icon-mata pt-3">
                                            <a> <img class="img-fluid" src="<?php echo e(asset('images/main/icon_view.png')); ?>"></a>
                                            <p><?php echo e($article->view); ?></p>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    </div>


    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/profile/profile-articleuser.blade.php ENDPATH**/ ?>