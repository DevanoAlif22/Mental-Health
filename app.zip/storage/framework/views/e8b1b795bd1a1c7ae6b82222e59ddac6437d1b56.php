<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mental Health - List Profil</title>

    <link rel="stylesheet" href="/css/navbar/style.css">
    <link rel="stylesheet" href="/css/footer/style.css">
    <link rel="icon" href="/images/main/logo2.png" type="image/png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/css/content/profile_style.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    
    <?php echo $__env->make('layout.navbarDefault', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container">

        <div class="row mt-4">
            <div class="col-lg-5">
                <div class="search">
                    <div class="icon">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                    <div class="inputan">
                        <form action="/list-profile" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="name" placeholder="Cari disini..">

                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="filter justify-content-end">
                    <a style=" <?php if($follow == true): ?> background-color: #0044a3; <?php endif; ?> margin-right: 20px" href="/list-profile-follower">Pengikut</a>
                    <a style=" <?php if($view == true): ?> background-color: #0044a3; <?php endif; ?> margin-right: 20px" href="/list-profile-view">Melihat</a>
                    <a style="background-color: #0A6EF6" href="/list-profile">Muat ulang</a>
                </div>
            </div>
        </div>
    </div>
    
    
    <section class="wrap-profil mb-5">
        <div class="container">


            <div class="wrap-card-profil ">
                <div class="row mt-5">
                    <?php $__currentLoopData = $listUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 mt-2 mb-4">

                        <div class="card-profil">


                            <div class="img-profile"
                                <?php if($user->profiles->image == null): ?>
                                style="background-image: url('<?php echo e(asset('images/profile/null.png')); ?>'); background-size: cover;background-position: center;background-repeat: no-repeat; max-width: 400; height: 200px;">

                                <?php else: ?>
                                style="background-image: url(<?php echo e(asset($user->profiles->image)); ?>); background-size: cover;background-position: center;background-repeat: no-repeat; max-width: 400; height: 200px;">

                                <?php endif; ?>

                            </div>

                            <div class="section-profil text-center">
                                <h4 style="margin-bottom: 15px;"><?php echo e($user->name); ?></h4>
                                <a href="/profile-aboutuser/<?php echo e($user->id); ?>">Lihat Saya</a>
                            </div>
                            <div class="sosial-media text-center">
                                <div class="wrap-media">


                                    <div class="media ms-2">
                                        <a><img class="img-fluid" src="<?php echo e(asset('images/main/icon_pengikut.png')); ?>"
                                                alt=""></a>
                                    </div>
                                    <div class="des-media">

                                        <p>Followers</p>
                                        <p><?php echo e($user->follower_count); ?></p>
                                    </div>
                                </div>

                                <div class="wrap-media">

                                    <div class="media">
                                        <a><img class="img-fluid" src="<?php echo e(asset('images/main/icon_view.png')); ?>"
                                                alt=""></a>
                                    </div>
                                    <div class="des-media text-center">

                                        <p>Viewers</p>
                                        <p><?php echo e($user->profiles->view); ?></p>
                                    </div>
                                </div>


                            </div>


                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </div>
    </section>
    

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/content/listProfile.blade.php ENDPATH**/ ?>