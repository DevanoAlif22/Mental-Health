<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mental Health - Artikel</title>

    <link rel="stylesheet" href="/css/navbar/style.css">
    <link rel="stylesheet" href="/css/footer/style.css">
    <link rel="stylesheet" href="/css/navbar/style.css">
    <link rel="icon" href="/images/main/logo2.png" type="image/png">
    <link rel="stylesheet" href="/css/content/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>

<body>

    
    <?php echo $__env->make('layout.navbarArticle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid mb-5">
        <div class="container pt-3 mb-3">
            <a class="back" href="/home"><i class="fa-solid fa-arrow-left fa-3x"></i></a>
        </div>
        <div class="container">
            <div class="img-article" style="background-image: url('<?php echo e(asset($article->image)); ?>')"></div>
        </div>
        <div class="container" style="margin-bottom: 30px;">
            <div class="row">

                <div class="col-md-6 d-flex">
                    <div class="img-profile" style="max-width:60px;background-image: url(

                        <?php if($article->users->profiles->image == null): ?>
                        /images/profile/profile-null.png
                        <?php else: ?>
                        <?php echo e($article->users->profiles->image); ?>

                        <?php endif; ?>
                        )"></div>
                    <div style="margin-left: 20px">
                        <h3><?php echo e($article->title); ?></h3>
                        <h6><a style="text-decoration: none; color:black;" href="/profile-aboutuser/<?php echo e($article->users->id); ?>"><?php echo e($article->users->name); ?></a> </h6>
                    </div>

                </div>

                <div class="col-md-6">
                <div class="d-flex category">
                    <div style="margin-right: 20px; display:flex">
                        <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/view.png')); ?>" alt="">
                        <div style="margin-left: 10px; padding-top:5px">
                            <h6 style="line-height: 0.3cm">Dilihat</h6>
                            <h6><?php echo e($article->view); ?></h6>
                        </div>
                    </div>

                    <?php if(Auth::user() && $like == null): ?>
                    <form action="/like-article/<?php echo e($article->id); ?>" method="GET">
                        <div style="margin-right: 20px; display:flex">
                            <button type="submit" style="background-color: white; border: none; ">
                                <img style="background-color: #a6a6a6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                            </button>
                            <div style="margin-left: 10px; padding-top:5px">
                                <h6 style="line-height: 0.3cm">Disukai</h6>
                                <h6><?php echo e($totalLike); ?></h6>
                            </div>
                        </div>

                    </form>
                    <?php elseif(Auth::user() && $like != null): ?>
                    <form action="/like-article/<?php echo e($article->id); ?>" method="GET">
                        <div style="margin-right: 20px; display:flex">
                                <button style="background-color: white; border: none;">
                                    <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                                </button>
                                <div style="margin-left: 10px; padding-top:5px">
                                    <h6 style="line-height: 0.3cm">Disukai</h6>
                                    <h6><?php echo e($totalLike); ?></h6>
                                </div>
                            </div>
                    </form>
                    <?php else: ?>
                        <div style="margin-right: 20px; display:flex">
                            <button style="background-color: white; border: none; ">
                                <img style="background-color: #a6a6a6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                            </button>
                            <div style="margin-left: 10px; padding-top:5px">
                                <h6 style="line-height: 0.3cm">Disukai</h6>
                                <h6><?php echo e($totalLike); ?></h6>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div style="margin-right: 20px; display:flex; ">
                        <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/comment.png')); ?>" alt="">
                        <div style="margin-left: 10px; padding-top:5px">
                            <h6 style="line-height: 0.3cm">Komentar</h6>
                            <h6><?php echo e($totalComment); ?></h6>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>

        <div class="container mb-5" style="margin-bottom: 30px;">
            <div class="d-flex">
                <i class="fa-solid fa-calendar-days fa-1x" style="padding-top:5px; color: #a6a6a6;"></i>
                <p style="margin-left: 10px; "><?php echo e($article->created_at); ?></p>
            </div>
            <div class="content" style="margin-bottom: 20px">
                <?php echo nl2br(e($article->content)); ?>


            </div>
            <?php if($article->report == false): ?>
            <div style="margin-right: 20px; display:flex; ">
                <a href="/report-article/<?php echo e($article->id); ?>" class="laporkan">Laporkan</a>
            </div>
            <?php else: ?>
            <div style="margin-right: 20px; display:flex; ">
                <a style="pointer-events: none" href="/report-article/<?php echo e($article->id); ?>" class="laporkan-mati">Laporkan</a>
            </div>
            <?php endif; ?>
        </div>

        <div class="container" style="height: 3px; background-color:rgba(148, 148, 148, 0.474)"></div>
        <?php if(Auth::user()): ?>

        <div class="container mt-5 mb-5">
            <div class="row  d-flex justify-content-between">
                <div class="col-1 mb-3">
                    <div class="comment d-flex">
                        <?php if(Auth::user()->profiles->image == NULL): ?>
                            <img class="img-comment" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt="">
                        <?php else: ?>
                            <img class="img-comment" src="<?php echo e(Auth::user()->profiles->image); ?>" alt="">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-10">
                        <form method="POST" action="/comment-article/<?php echo e($article->id); ?>">
                            <?php echo csrf_field(); ?>
                        <input autocomplete="off" maxlength="200" class="text-comment" placeholder="Tambahkan Komentar" type="text" name="content" id="">
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-comment" type="submit">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
        <?php else: ?>
        <p style="padding-top: 15px" class="text-center"><a style=" text-decoration:none;" href="/login">Login</a> untuk komentar</p>
        <?php endif; ?>

        <?php if($article->commentArticle->isNotEmpty()): ?>
        <div class="container mt-5 list-comment">
            <?php $__currentLoopData = $article->commentArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-4 d-flex">
                <div class="col-1">
                    <?php if($items->users->profiles->image == NULL): ?>
                    <img class="img-comment" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt="">
                    <?php else: ?>
                    <img class="img-comment" src="<?php echo e($items->users->profiles->image); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="col-11">
                    <h5><?php echo e($items->users->name); ?></h5>
                    <div class="date-comment d-flex">
                        <i class="fa-solid fa-calendar-days fa-1x" style="padding-top:5px; color: #a6a6a6;"></i>
                <p style="margin-left: 10px; "><?php echo e($items->created_at); ?></p>
                    </div>
                    <p><?php echo e($items->content); ?></p>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/content/article.blade.php ENDPATH**/ ?>