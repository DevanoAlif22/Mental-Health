<?php if($errors->any()): ?>
    <div class="alert alert-danger" style="width: 350px !important">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($item); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

<?php endif; ?>
<?php if(Session::get('success')): ?>
    <div style="width: 350px !important" class="alert alert-success alert-dismissible fade show">
        <ul>
            <li><?php echo e(Session::get('success')); ?></li>
        </ul>
    </div>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/layout/message.blade.php ENDPATH**/ ?>