<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mental Health - Story</title>

    <link rel="stylesheet" href="/css/navbar/style.css">
    <link rel="stylesheet" href="/css/footer/style.css">
    <link rel="icon" href="/images/main/logo2.png" type="image/png">
    <link rel="stylesheet" href="/css/content/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  </head>
  <body>


    
    <?php echo $__env->make('layout.navbarStory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid mb-5">
        <div class="container pt-3 mb-3">
            <a class="back" href="/home"><i class="fa-solid fa-arrow-left fa-3x"></i></a>

        </div>
        <div class="container">
            <div class="img-article" style="background-image: url('<?php echo e(asset($story->image)); ?>')"></div>
        </div>
        <div class="container mb-5">
            <audio controls style="width: 100%">
                <source src="<?php echo e($story->audio); ?>" type="audio/mp3">
                Your browser does not support the audio element.
              </audio>
        </div>
        <div class="container" style="margin-bottom: 30px;">
            <div class="row">

                <div class="col-md-6 d-flex">
                    <?php if($story->users->profiles->image == null): ?>
                    <img class="img-profile" style="max-width: 65px" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt="">
                    <?php else: ?>
                    <img class="img-profile" style="max-width: 65px" src="<?php echo e(asset($story->users->profiles->image)); ?>" alt="">
                    <?php endif; ?>
                    <div style="margin-left: 20px">
                        <h3><?php echo e($story->title); ?></h3>
                        <div class="d-flex">
                            <h6 style="padding-top: 10px; margin-right:20px;"><a style="text-decoration: none; color:black;" href="/profile-aboutuser/<?php echo e($story->users->id); ?>"><?php echo e($story->users->name); ?></a> </h6>
                            <div class="kategori">
                                <?php $__currentLoopData = $story->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="text-white " style="text-decoration: none;"><?php echo e($category->storyCategory->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="col-md-6">
                <div class="d-flex category">
                    <div style="margin-right: 20px; display:flex">
                        <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/view.png')); ?>" alt="">
                        <div style="margin-left: 10px; padding-top:5px">
                            <h6 style="line-height: 0.3cm">Dilihat</h6>
                            <h6><?php echo e($story->view); ?></h6>
                        </div>
                    </div>
                    <?php if(Auth::user() && $like == null): ?>
                    <form action="/like-story/<?php echo e($story->id); ?>" method="GET">
                        <div style="margin-right: 20px; display:flex">
                            <button type="submit" style="background-color: white; border: none; ">
                                <img style="background-color: #a6a6a6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                            </button>
                            <div style="margin-left: 10px; padding-top:5px">
                                <h6 style="line-height: 0.3cm">Disukai</h6>
                                <h6><?php echo e($totalLike); ?></h6>
                            </div>
                        </div>

                    </form>
                    <?php elseif(Auth::user() && $like != null): ?>
                    <form action="/like-story/<?php echo e($story->id); ?>" method="GET">
                        <div style="margin-right: 20px; display:flex">
                                <button style="background-color: white; border: none;">
                                    <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                                </button>
                                <div style="margin-left: 10px; padding-top:5px">
                                    <h6 style="line-height: 0.3cm">Disukai</h6>
                                    <h6><?php echo e($totalLike); ?></h6>
                                </div>
                            </div>
                    </form>
                    <?php else: ?>
                        <div style="margin-right: 20px; display:flex">
                            <button style="background-color: white; border: none; ">
                                <img style="background-color: #a6a6a6;" src="<?php echo e(asset('images/content/like.png')); ?>" alt="">
                            </button>
                            <div style="margin-left: 10px; padding-top:5px">
                                <h6 style="line-height: 0.3cm">Disukai</h6>
                                <h6><?php echo e($totalLike); ?></h6>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div style="margin-right: 20px; display:flex; ">
                        <img style="background-color: #0a6ef6;" src="<?php echo e(asset('images/content/comment.png')); ?>" alt="">
                        <div style="margin-left: 10px; padding-top:5px">
                            <h6 style="line-height: 0.3cm">Komentar</h6>
                            <h6><?php echo e($totalComment); ?></h6>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>

        <div class="container mb-5" style="margin-bottom: 30px;">
            <div class="d-flex">
                <i class="fa-solid fa-calendar-days fa-1x" style="padding-top:5px; color: #a6a6a6;"></i>
                <p style="margin-left: 10px; "><?php echo e($story->created_at); ?></p>
            </div>
            <div class="content" style="margin-bottom: 20px">
                <?php echo e($story->description); ?>

            </div>

            <?php if($story->report == false): ?>
            <div style="margin-right: 20px; display:flex; ">
                <a href="/report-story/<?php echo e($story->id); ?>" class="laporkan">Laporkan</a>
            </div>
            <?php else: ?>
            <div style="margin-right: 20px; display:flex; ">
                <a style="pointer-events: none" href="/report-story/<?php echo e($story->id); ?>" class="laporkan-mati">Laporkan</a>
            </div>
            <?php endif; ?>
        </div>
        <div class="container" style="height: 3px; background-color:rgba(148, 148, 148, 0.474)"></div>
        <?php if(Auth::user()): ?>

        <div class="container mt-5 mb-5">
            <div class="row  d-flex justify-content-between">
                <div class="col-1 mb-3">
                    <div class="comment d-flex">
                        <?php if(Auth::user()->profiles->image == NULL): ?>
                            <img class="img-comment" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt="">
                        <?php else: ?>
                            <img class="img-comment" src="<?php echo e(Auth::user()->profiles->image); ?>" alt="">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-10">
                        <form method="POST" action="/comment-story/<?php echo e($story->id); ?>">
                            <?php echo csrf_field(); ?>
                        <input autocomplete="off" maxlength="200" class="text-comment" placeholder="Tambahkan Komentar" type="text" name="content" id="">
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-comment" type="submit">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
        <?php else: ?>
        <p style="padding-top: 15px" class="text-center"><a style=" text-decoration:none;" href="/login">Login</a> untuk komentar</p>
        <?php endif; ?>

        <?php if($story->storyComment->isNotEmpty()): ?>
        <div class="container mt-5 list-comment">
            <?php $__currentLoopData = $story->storyComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row mb-4 d-flex">
                <div class="col-1">
                    <?php if($items->users->profiles->image == NULL): ?>
                    <img class="img-comment" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt="">
                    <?php else: ?>
                    <img class="img-comment" src="<?php echo e($items->users->profiles->image); ?>" alt="">
                    <?php endif; ?>
                </div>
                <div class="col-11">
                    <h5><?php echo e($items->users->name); ?></h5>
                    <div class="date-comment d-flex">
                        <i class="fa-solid fa-calendar-days fa-1x" style="padding-top:5px; color: #a6a6a6;"></i>
                <p style="margin-left: 10px; "><?php echo e($items->created_at); ?></p>
                    </div>
                    <p><?php echo e($items->content); ?></p>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/content/story.blade.php ENDPATH**/ ?>