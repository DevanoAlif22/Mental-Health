
    
    <footer>
        <div class="container">
            <div class="row wrap-footer">
                <div class="col-lg-4 pt-4 ">
                    <div class="logo-footer ">
                        <div class="bungkus-logo text-center">

                            <img class="img-fluid" src="<?php echo e(asset('images/main/logo-putih.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="des-footer ">


                        <p>Website Mental Health Adalah website yang menyediakan fitur Artikel, Cerita dan Sistem Pakar</p>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="judul-media-footer">
                        <p>Social Media</p>
                    </div>
                    <div class="icon-media-footer">
                        <div class="wrap-link-media">

                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/ig.png')); ?>"
                                    alt=""></a>
                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/fb.png')); ?>"
                                    alt=""></a>
                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/linkd.png')); ?>"
                                    alt=""></a>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="judul-kontak">
                        <p>Contact Us</p>
                    </div>
                    <div class="isi-kontak">
                        <p>webmentalhealth1@gmail.com</p>
                        <p style="margin-top: -1rem">0895366141915</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="create text-white text-center pt-2">
            <p>@Createbykakacksquad</p>
        </div>
    </footer>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/layout/footer.blade.php ENDPATH**/ ?>