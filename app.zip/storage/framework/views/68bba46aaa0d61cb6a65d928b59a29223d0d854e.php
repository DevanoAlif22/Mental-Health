<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mental Health - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="<?php echo e(asset('/css/content/listArticle_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/content/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<style>
    body {
        overflow-x: hidden;
    }
</style>

<body>
    
    <nav class="navbar navbar-expand-lg bg-trasnparant">
        <div class="container wrap_navbar pt-3">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('images/main/logo_mentahan.png')); ?>" alt="">Mental Health
            </a>
            <button style="border: none; color: rgba(0, 12, 12, 0)" class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup"
                aria-expanded="false" aria-label="navigation">
                <span class="">
                    <p style="color: #0A6EF6"><i class="fa-solid fa-bars"></i></p>
                </span>
            </button>
            <div class="collapse navbar-collapse" style="justify-content: end" id="navbarNavAltMarkup">
                <div class="navbar-nav" id="aboutme">
                    <a class="nav-link aktive" href="/home">Beranda</a>
                    <a class="nav-link" href="/sistem-pakar">Sistem pakar</a>
                    <?php if(Auth::user()): ?>
                        <?php if($imageProfile == null): ?>
                            <a class="nav-link" href="/profile-aboutuser/<?php echo e(Auth::user()->id); ?>"><img style="width: 35px; height: 35px; margin-top:-10px" src="<?php echo e(asset('images/profile/profile-null.png')); ?>" alt=""></a>
                        <?php else: ?>
                            <a  class="nav-link" href="/profile-aboutuser/<?php echo e(Auth::user()->id); ?>"><img style="width: 40px; height: 40px; border-radius:50%;" src="<?php echo e(asset(Auth::user()->profiles->image)); ?>" alt=""></a>
                        <?php endif; ?>
                    <?php else: ?>
                    <button><a style="" href="<?php echo e(route('auth')); ?>">Login</a></button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>


    <div class="container-fluid p-3">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <footer>
        <div class="container">
            <div class="row wrap-footer">
                <div class="col-lg-4 pt-4 ">
                    <div class="logo-footer ">
                        <div class="bungkus-logo text-center">

                            <img class="img-fluid" src="<?php echo e(asset('images/main/logo-putih.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="des-footer ">


                        <p>Website Mental Health Adalah website yang menyediakan fitur Artikel, Cerita dan Sistem Pakar</p>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="judul-media-footer">
                        <p>Social Media</p>
                    </div>
                    <div class="icon-media-footer">
                        <div class="wrap-link-media">

                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/ig.png')); ?>"
                                    alt=""></a>
                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/fb.png')); ?>"
                                    alt=""></a>
                            <a href=""> <img class="img-fluid" src="<?php echo e(asset('images/main/linkd.png')); ?>"
                                    alt=""></a>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="judul-kontak">
                        <p>Contact Us</p>
                    </div>
                    <div class="isi-kontak">
                        <p>webmentalhealth1@gmail.com</p>
                        <p style="margin-top: -1rem">0895366141915</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="create text-white text-center pt-2">
            <p>@Createbykakacksquad</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mentalhealth\resources\views/layout/content.blade.php ENDPATH**/ ?>